let videojuegos = [];
let carrito = [];
let totalCompra = 0;

document.addEventListener("DOMContentLoaded", () => {
    cargarVideojuegosDeLocalStorage();
    cargarVideojuegos(videojuegos);
});

function cargarVideojuegosDeLocalStorage() {
    const data = localStorage.getItem('videojuegos');
    if (data) {
        videojuegos = JSON.parse(data);
    }
}

function cargarVideojuegos(videojuegos) {
    const container = document.getElementById('videojuegosContainer');
    container.innerHTML = '';
    videojuegos.forEach(vj => {
        const card = document.createElement('div');
        card.className = 'col-md-4';
        card.innerHTML = `
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">${vj.nombre}</h5>
                    <p class="card-text">${vj.descripcion}</p>
                    <p class="card-text">$${vj.precio}</p>
                    <button class="btn btn-primary" onclick="agregarAlCarrito(${vj.id})">Agregar al Carrito</button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

function filtrarPorCategoria() {
    const categoria = document.getElementById('categoriaSelect').value;
    const filtrados = categoria === 'todos' ? videojuegos : videojuegos.filter(vj => vj.categoria === categoria);
    cargarVideojuegos(filtrados);
}

function agregarAlCarrito(id) {
    const vj = videojuegos.find(vj => vj.id === id);
    carrito.push(vj);
    actualizarCarrito();
}

function actualizarCarrito() {
    const carritoContainer = document.getElementById('carrito');
    carritoContainer.innerHTML = '';
    let total = 0;
    carrito.forEach(vj => {
        const item = document.createElement('li');
        item.className = 'list-group-item';
        item.textContent = `${vj.nombre} - $${vj.precio}`;
        carritoContainer.appendChild(item);
        total += vj.precio;
    });
    totalCompra = carrito.length > 3 ? total * 0.85 : total;
    document.getElementById('total').textContent = totalCompra.toFixed(2);
}

function realizarCompra() {
    guardarVentasEnLocalStorage();
    alert(`Compra realizada. Total: $${totalCompra.toFixed(2)}`);
    carrito = [];
    actualizarCarrito();
}

function guardarVentasEnLocalStorage() {
    const ventas = JSON.parse(localStorage.getItem('ventas')) || [];

    const clientes = JSON.parse(localStorage.getItem('clientes')) || [];
    const clienteSelect = document.getElementById('clienteSelect');
    const opcionSeleccionada = clienteSelect.value;
    let elCliente = [];

    for (let i = 0; i < clientes.length; i++) {
        if(opcionSeleccionada == clientes[i].id){
            elCliente = clientes[i];
            
        }
    }
    const ahora = new Date(); 
    const fechaVenta = ahora.toLocaleDateString(); 
    const horaVenta = ahora.toLocaleTimeString();
    const fechaHoraVenta = `${fechaVenta} ${horaVenta}`;
        carrito.forEach(vj => {
        const ventaExistente = ventas.find(venta => venta.id === vj.id);
        if (ventaExistente) {
            ventaExistente.cantidad += 1;
        } else {
            ventas.push({ cliente: elCliente, videojuego: vj, cantidad: 1, fechaHoraVenta});
        }
        
    });
    localStorage.setItem('ventas', JSON.stringify(ventas));
}
